from sqlmodel import SQLModel, Field, create_engine, Session, select
from typing import Optional
from datetime import datetime
import uuid

DATABASE_URL = "sqlite:///./workflow_platform.db"
engine = create_engine(DATABASE_URL, echo=False)


def get_session():
    with Session(engine) as session:
        yield session


def init_db():
    SQLModel.metadata.create_all(engine)


# ─── Models ───────────────────────────────────────────────────────────────────

class WorkflowStep(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    workflow_id: str = Field(index=True)
    step_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    endpoint: str
    http_method: str  # GET POST PUT DELETE PATCH
    headers: Optional[str] = None   # JSON string
    body: Optional[str] = None      # JSON string
    extract_vars: Optional[str] = None  # JSON: {"var_name": "response.path"}
    condition: Optional[str] = None    # e.g. "status == 200"
    retry_count: int = Field(default=0)
    execution_order: int = Field(default=0)


class Workflow(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    workflow_id: str = Field(default_factory=lambda: str(uuid.uuid4()), index=True, unique=True)
    name: str
    description: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    version: str = Field(default="1.0")


class Execution(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    execution_id: str = Field(default_factory=lambda: str(uuid.uuid4()), index=True, unique=True)
    workflow_id: str = Field(index=True)
    status: str = Field(default="pending")  # pending running success failed
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    concurrency: int = Field(default=1)
    iterations: int = Field(default=1)
    use_mock: bool = Field(default=False)
    error_message: Optional[str] = None


class ExecutionTrace(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    trace_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    execution_id: str = Field(index=True)
    step_id: str
    step_name: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    response_time: float = Field(default=0.0)  # ms
    status_code: Optional[int] = None
    outcome: str = Field(default="pending")  # success fail skipped
    response_body: Optional[str] = None
    error: Optional[str] = None
    worker_id: int = Field(default=0)


class MockApiConfig(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    mock_id: str = Field(default_factory=lambda: str(uuid.uuid4()), index=True, unique=True)
    endpoint: str
    http_method: str
    response_template: str  # JSON string
    latency_min: int = Field(default=0)    # ms
    latency_max: int = Field(default=100)  # ms
    error_rate: float = Field(default=0.0) # 0.0 to 1.0
    status_code: int = Field(default=200)
